import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.*;

public class UIStyles {

    // Modern Dark Theme Colors
    public static final Color BG = new Color(18, 18, 18);
    public static final Color CARD = new Color(30, 30, 30);
    public static final Color PRIMARY = new Color(0, 150, 136); // Teal
    public static final Color HOVER = new Color(0, 180, 164);
    public static final Color TEXT = new Color(240, 240, 240);
    public static final Color TEXT_MUTED = new Color(150, 150, 150);
    public static final Color BORDER_COLOR = new Color(50, 50, 50);

    // Fonts
    public static final Font FONT_HEADING = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font FONT_BODY = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_BOLD_BODY = new Font("Segoe UI", Font.BOLD, 14);

    // Rounded card with subtle borders
    public static JPanel card(int arc) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Shadow simulation
                g2.setColor(new Color(0, 0, 0, 50));
                g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, arc, arc);
                
                // Main card body
                g2.setColor(CARD);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, arc, arc);
                
                // Border
                g2.setColor(BORDER_COLOR);
                g2.setStroke(new BasicStroke(1));
                g2.drawRoundRect(0, 0, getWidth() - 2, getHeight() - 2, arc, arc);
                
                g2.dispose();
                super.paintComponent(g);
            }
        };
    }

    // Modern button with hover + click effects
    public static JButton button(String text) {
        JButton b = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(PRIMARY.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(HOVER);
                } else {
                    g2.setColor(PRIMARY);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setFocusPainted(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFont(FONT_BOLD_BODY);
        b.setForeground(Color.WHITE);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(10, 20, 10, 20));
        return b;
    }

    // Danger Button
    public static JButton dangerButton(String text) {
        JButton b = button(text);
        b.setBackground(new Color(220, 53, 69)); // Red
        return b;
    }

    // Heading label
    public static JLabel heading(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(TEXT);
        l.setFont(FONT_HEADING);
        return l;
    }

    public static JLabel title(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(TEXT);
        l.setFont(FONT_TITLE);
        return l;
    }

    public static JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(TEXT_MUTED);
        l.setFont(FONT_BODY);
        return l;
    }

    // Custom Rounded Border for Inputs
    static class RoundedBorder implements Border {
        private int radius;
        RoundedBorder(int radius) {
            this.radius = radius;
        }
        public Insets getBorderInsets(Component c) {
            return new Insets(2, 2, 2, 2); // minimal insets for the drawn border
        }
        public boolean isBorderOpaque() {
            return true;
        }
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D)g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(BORDER_COLOR);
            g2.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }
    }

    public static JTextField input() {
        JTextField f = new JTextField();
        f.setFont(FONT_BODY);
        f.setBackground(BG);
        f.setForeground(TEXT);
        f.setCaretColor(PRIMARY);
        f.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(8),
            new EmptyBorder(8, 10, 8, 10)
        ));
        return f;
    }
    
    public static JPasswordField passwordInput() {
        JPasswordField f = new JPasswordField();
        f.setFont(FONT_BODY);
        f.setBackground(BG);
        f.setForeground(TEXT);
        f.setCaretColor(PRIMARY);
        f.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(8),
            new EmptyBorder(8, 10, 8, 10)
        ));
        return f;
    }

    public static JComboBox<String> combo() {
        JComboBox<String> c = new JComboBox<>();
        c.setFont(FONT_BODY);
        c.setBackground(BG);
        c.setForeground(TEXT);
        // Basic combo styling, can be complex in plain swing.
        return c;
    }

    // Custom ScrollPane styling
    public static JScrollPane scroll(Component view) {
        JScrollPane sp = new JScrollPane(view);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.getViewport().setBackground(BG);
        
        sp.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = CARD.brighter();
                this.trackColor = BG;
            }
            @Override
            protected JButton createDecreaseButton(int orientation) {
                return createZeroButton();
            }
            @Override
            protected JButton createIncreaseButton(int orientation) {
                return createZeroButton();
            }
            private JButton createZeroButton() {
                JButton jbutton = new JButton();
                jbutton.setPreferredSize(new Dimension(0, 0));
                jbutton.setMinimumSize(new Dimension(0, 0));
                jbutton.setMaximumSize(new Dimension(0, 0));
                return jbutton;
            }
        });
        return sp;
    }

    public static void styleTable(JTable table) {
        table.setBackground(CARD);
        table.setForeground(TEXT);
        table.setFont(FONT_BODY);
        table.setRowHeight(35);
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(BORDER_COLOR);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setBorder(BorderFactory.createEmptyBorder());

        // Header Styling
        table.getTableHeader().setBackground(CARD.darker());
        table.getTableHeader().setForeground(PRIMARY);
        table.getTableHeader().setFont(FONT_BOLD_BODY);
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, PRIMARY));
        table.getTableHeader().setPreferredSize(new Dimension(100, 40));
        
        // Custom Renderer for padding
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setBorder(new EmptyBorder(0, 15, 0, 15));
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
    }
}