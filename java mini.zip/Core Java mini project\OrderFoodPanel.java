import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.LinkedHashMap;

public class OrderFoodPanel extends JPanel {

    private LinkedHashMap<String, Double> cart = new LinkedHashMap<>();
    private JComboBox<String> foodCombo;
    private JTextArea billArea;
    private JLabel totalLabel;

    public OrderFoodPanel() {
        setLayout(new BorderLayout(20, 20));
        setBackground(UIStyles.BG);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create a Split Pane layout manually using a GridBagLayout or a GridLayout
        JPanel splitPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        splitPanel.setBackground(UIStyles.BG);

        // --- LEFT PANEL: Order Form ---
        JPanel leftPanel = UIStyles.card(15);
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        titlePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        JLabel title = UIStyles.heading("Place Order");
        JButton refreshBtn = UIStyles.button("🔄");
        refreshBtn.setToolTipText("Refresh Food List");
        refreshBtn.addActionListener(e -> loadFoodItems());
        titlePanel.add(title, BorderLayout.CENTER);
        titlePanel.add(refreshBtn, BorderLayout.EAST);

        JPanel foodPanel = new JPanel(new BorderLayout(0, 5));
        foodPanel.setOpaque(false);
        foodPanel.add(UIStyles.label("Select Food Item"), BorderLayout.NORTH);
        foodCombo = UIStyles.combo();
        foodPanel.add(foodCombo, BorderLayout.CENTER);

        JPanel qtyPanel = new JPanel(new BorderLayout(0, 5));
        qtyPanel.setOpaque(false);
        qtyPanel.add(UIStyles.label("Quantity"), BorderLayout.NORTH);
        JTextField qtyField = UIStyles.input();
        qtyField.setText("1");
        qtyPanel.add(qtyField, BorderLayout.CENTER);

        JButton addBtn = UIStyles.button("Add to Cart 🛒");
        addBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        addBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));

        leftPanel.add(titlePanel);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        leftPanel.add(foodPanel);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        leftPanel.add(qtyPanel);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        leftPanel.add(addBtn);

        // --- RIGHT PANEL: Cart / Bill ---
        JPanel rightPanel = UIStyles.card(15);
        rightPanel.setLayout(new BorderLayout(0, 10));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel billTitle = UIStyles.heading("Current Cart");
        billTitle.setHorizontalAlignment(SwingConstants.CENTER);
        
        billArea = new JTextArea();
        billArea.setBackground(UIStyles.BG);
        billArea.setForeground(Color.WHITE);
        billArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        billArea.setEditable(false);
        billArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JScrollPane scrollPane = UIStyles.scroll(billArea);
        
        JPanel bottomBillPanel = new JPanel(new BorderLayout());
        bottomBillPanel.setOpaque(false);
        bottomBillPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIStyles.BORDER_COLOR));
        
        totalLabel = UIStyles.title("Total: ₹ 0.00");
        totalLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JButton printBtn = UIStyles.button("Print Bill 🖨️");
        
        bottomBillPanel.add(totalLabel, BorderLayout.CENTER);
        bottomBillPanel.add(printBtn, BorderLayout.EAST);

        rightPanel.add(billTitle, BorderLayout.NORTH);
        rightPanel.add(scrollPane, BorderLayout.CENTER);
        rightPanel.add(bottomBillPanel, BorderLayout.SOUTH);

        splitPanel.add(leftPanel);
        splitPanel.add(rightPanel);

        add(splitPanel, BorderLayout.CENTER);

        // Load items into Combo
        loadFoodItems();

        // Actions
        addBtn.addActionListener(e -> {
            String item = (String) foodCombo.getSelectedItem();
            if (item == null) return;
            
            try {
                int q = Integer.parseInt(qtyField.getText());
                if (q <= 0) throw new NumberFormatException();

                double price = fetchPrice(item);
                if (price > 0) {
                    cart.put(item, cart.getOrDefault(item, 0.0) + (price * q));
                    updateBillArea();
                    qtyField.setText("1");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid quantity.", "Invalid Quantity", JOptionPane.ERROR_MESSAGE);
            }
        });

        printBtn.addActionListener(e -> {
            if (cart.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Cart is empty!", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }
            JOptionPane.showMessageDialog(this, "Bill Printed Successfully!\n" + totalLabel.getText(), "Success", JOptionPane.INFORMATION_MESSAGE);
            cart.clear();
            updateBillArea();
        });
        
        updateBillArea(); // initial clear
    }

    private void loadFoodItems() {
        foodCombo.removeAllItems();
        try {
            Class.forName("org.sqlite.JDBC");
            try (Connection con = DriverManager.getConnection("jdbc:sqlite:restaurant_db.db");
                 Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT name FROM food_items")) {
                
                while (rs.next()) {
                    foodCombo.addItem(rs.getString(1));
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading food items: " + e.getMessage());
        }
    }

    private double fetchPrice(String itemName) {
        try {
            Class.forName("org.sqlite.JDBC");
            try (Connection con = DriverManager.getConnection("jdbc:sqlite:restaurant_db.db");
                 PreparedStatement pst = con.prepareStatement("SELECT price FROM food_items WHERE name=?")) {
                
                pst.setString(1, itemName);
                try (ResultSet rs = pst.executeQuery()) {
                    if (rs.next()) return rs.getDouble(1);
                }
            }
        } catch (Exception e) {
            System.out.println("Error fetching price: " + e.getMessage());
        }
        return 0;
    }

    private void updateBillArea() {
        double total = 0;
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-20s %10s\n", "Item", "Price"));
        sb.append("--------------------------------\n");
        
        for (String k : cart.keySet()) {
            double p = cart.get(k);
            sb.append(String.format("%-20s ₹%9.2f\n", k, p));
            total += p;
        }
        
        if (cart.isEmpty()) {
            sb.append("\n  No items in cart.\n");
        }
        
        billArea.setText(sb.toString());
        totalLabel.setText(String.format("Total: ₹ %.2f", total));
    }
}