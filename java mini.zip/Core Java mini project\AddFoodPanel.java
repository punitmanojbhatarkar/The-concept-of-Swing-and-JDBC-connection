import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class AddFoodPanel extends JPanel {

    public AddFoodPanel() {

        setBackground(UIStyles.BG);
        setLayout(new GridBagLayout()); // Center the card

        JPanel card = UIStyles.card(15);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        card.setPreferredSize(new Dimension(400, 300));
        card.setMinimumSize(new Dimension(400, 300));

        JLabel title = UIStyles.heading("Add New Item");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel namePanel = new JPanel(new BorderLayout(0, 5));
        namePanel.setOpaque(false);
        namePanel.add(UIStyles.label("Food Name"), BorderLayout.NORTH);
        JTextField name = UIStyles.input();
        namePanel.add(name, BorderLayout.CENTER);

        JPanel pricePanel = new JPanel(new BorderLayout(0, 5));
        pricePanel.setOpaque(false);
        pricePanel.add(UIStyles.label("Price (₹)"), BorderLayout.NORTH);
        JTextField price = UIStyles.input();
        pricePanel.add(price, BorderLayout.CENTER);

        JButton add = UIStyles.button("Save Item");
        add.setAlignmentX(Component.CENTER_ALIGNMENT);
        add.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));

        card.add(title);
        card.add(Box.createRigidArea(new Dimension(0, 25)));
        card.add(namePanel);
        card.add(Box.createRigidArea(new Dimension(0, 15)));
        card.add(pricePanel);
        card.add(Box.createRigidArea(new Dimension(0, 25)));
        card.add(add);

        add(card);

        add.addActionListener(e -> {
            String fName = name.getText().trim();
            String fPrice = price.getText().trim();

            if (fName.isEmpty() || fPrice.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                double p = Double.parseDouble(fPrice);
                
                Class.forName("org.sqlite.JDBC");
                try (Connection con = DriverManager.getConnection("jdbc:sqlite:restaurant_db.db")) {
                    
                    PreparedStatement check = con.prepareStatement("SELECT * FROM food_items WHERE name=?");
                    check.setString(1, fName);
                    
                    if (check.executeQuery().next()) {
                        JOptionPane.showMessageDialog(this, "Item already exists in the menu", "Info", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        PreparedStatement pst = con.prepareStatement("INSERT INTO food_items(name,price) VALUES(?,?)");
                        pst.setString(1, fName);
                        pst.setDouble(2, p);
                        pst.executeUpdate();
                        JOptionPane.showMessageDialog(this, "Item added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        name.setText("");
                        price.setText("");
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid price format. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}