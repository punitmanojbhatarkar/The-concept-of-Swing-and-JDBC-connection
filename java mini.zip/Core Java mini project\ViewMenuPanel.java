import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewMenuPanel extends JPanel {

    public ViewMenuPanel() {

        setLayout(new BorderLayout(0, 10));
        setBackground(UIStyles.BG);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header section
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        JLabel title = UIStyles.heading("Current Menu");
        JButton refreshBtn = UIStyles.button("🔄 Refresh");
        headerPanel.add(title, BorderLayout.WEST);
        headerPanel.add(refreshBtn, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        // Table setup
        String[] cols = {"Item ID", "Food Name", "Price (₹)"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // read-only
            }
        };
        
        JTable table = new JTable(model);
        UIStyles.styleTable(table);

        JScrollPane scrollPane = UIStyles.scroll(table);
        
        // Wrap scroll pane in a card for soft border effect
        JPanel tableCard = UIStyles.card(15);
        tableCard.setLayout(new BorderLayout());
        tableCard.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        tableCard.add(scrollPane, BorderLayout.CENTER);

        add(tableCard, BorderLayout.CENTER);

        // Load data function
        Runnable loadData = () -> {
            model.setRowCount(0); // clear existing
            try {
                Class.forName("org.sqlite.JDBC");
                try (Connection con = DriverManager.getConnection("jdbc:sqlite:restaurant_db.db");
                     Statement stmt = con.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT * FROM food_items")) {
                    
                    while (rs.next()) {
                        model.addRow(new Object[]{
                                rs.getInt(1), rs.getString(2), String.format("%.2f", rs.getDouble(3))
                        });
                    }
                }
            } catch (Exception e) {
                System.out.println("Error loading menu: " + e.getMessage());
            }
        };

        // Initial load
        loadData.run();

        // Refresh action
        refreshBtn.addActionListener(e -> loadData.run());
    }
}