import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Dashboard extends JFrame {

    private CardLayout cl = new CardLayout();
    private JPanel content = new JPanel(cl);
    private JButton activeBtn; // To track active sidebar button

    public Dashboard() {

        setTitle("Restaurant Management System - Dashboard");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UIStyles.BG);

        // --- TOP HEADER ---
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIStyles.CARD);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UIStyles.BORDER_COLOR),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));

        JLabel title = UIStyles.heading("Dashboard");
        JLabel userInfo = UIStyles.label("Welcome, Admin | " + new SimpleDateFormat("MMM dd, yyyy").format(new Date()));
        
        header.add(title, BorderLayout.WEST);
        header.add(userInfo, BorderLayout.EAST);

        // --- SIDEBAR ---
        JPanel side = new JPanel();
        side.setBackground(UIStyles.CARD);
        side.setLayout(new BorderLayout());
        side.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UIStyles.BORDER_COLOR));
        side.setPreferredSize(new Dimension(220, 0));

        JPanel sideMenu = new JPanel();
        sideMenu.setOpaque(false);
        sideMenu.setLayout(new BoxLayout(sideMenu, BoxLayout.Y_AXIS));
        sideMenu.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));

        JLabel menuLabel = UIStyles.label("MAIN MENU");
        menuLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        sideMenu.add(menuLabel);
        sideMenu.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton b1 = createSidebarButton("🍔  Add Food");
        JButton b2 = createSidebarButton("📋  View Menu");
        JButton b3 = createSidebarButton("🛒  Order Food");
        JButton b4 = UIStyles.dangerButton("🚪  Logout");
        
        // Ensure standard width
        Dimension maxBtnSize = new Dimension(Integer.MAX_VALUE, 45);
        b1.setMaximumSize(maxBtnSize);
        b2.setMaximumSize(maxBtnSize);
        b3.setMaximumSize(maxBtnSize);
        b4.setMaximumSize(maxBtnSize);

        sideMenu.add(b1);
        sideMenu.add(Box.createRigidArea(new Dimension(0, 10)));
        sideMenu.add(b2);
        sideMenu.add(Box.createRigidArea(new Dimension(0, 10)));
        sideMenu.add(b3);

        side.add(sideMenu, BorderLayout.NORTH);
        
        JPanel bottomSide = new JPanel();
        bottomSide.setOpaque(false);
        bottomSide.setLayout(new BoxLayout(bottomSide, BoxLayout.Y_AXIS));
        bottomSide.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));
        bottomSide.add(b4);
        side.add(bottomSide, BorderLayout.SOUTH);

        // --- PAGES ---
        content.setBackground(UIStyles.BG);
        content.add(new AddFoodPanel(), "add");
        content.add(new ViewMenuPanel(), "view");
        content.add(new OrderFoodPanel(), "order");

        // Action Listeners
        b1.addActionListener(e -> { cl.show(content,"add"); title.setText("Add Food"); setActive(b1, b2, b3); });
        b2.addActionListener(e -> { cl.show(content,"view"); title.setText("View Menu"); setActive(b2, b1, b3); });
        b3.addActionListener(e -> { cl.show(content,"order"); title.setText("Order Food"); setActive(b3, b1, b2); });
        b4.addActionListener(e -> { new LoginScreen(); dispose(); });

        // Default state
        setActive(b1, b2, b3);
        title.setText("Add Food");

        root.add(header, BorderLayout.NORTH);
        root.add(side, BorderLayout.WEST);
        root.add(content, BorderLayout.CENTER);

        add(root);
        setVisible(true);
    }

    private JButton createSidebarButton(String text) {
        JButton b = UIStyles.button(text);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setBackground(UIStyles.CARD); // Default is card color (transparent looking)
        b.setForeground(UIStyles.TEXT_MUTED);
        return b;
    }

    private void setActive(JButton active, JButton... others) {
        active.setBackground(UIStyles.PRIMARY.darker());
        active.setForeground(Color.WHITE);
        for (JButton b : others) {
            b.setBackground(UIStyles.CARD);
            b.setForeground(UIStyles.TEXT_MUTED);
        }
    }
}