import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginScreen extends JFrame {

    public LoginScreen() {
        setTitle("Restaurant Management System - Login");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UIStyles.BG);

        // Left Panel - Branding
        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(UIStyles.PRIMARY);
        leftPanel.setLayout(new GridBagLayout());
        leftPanel.setPreferredSize(new Dimension(300, 0));
        
        JLabel brandTitle = new JLabel("<html><center>Restaurant<br>Manager</center></html>");
        brandTitle.setFont(new Font("Segoe UI", Font.BOLD, 32));
        brandTitle.setForeground(Color.WHITE);
        leftPanel.add(brandTitle);

        // Right Panel - Login Form
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(UIStyles.BG);

        JPanel card = UIStyles.card(20);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        card.setPreferredSize(new Dimension(350, 420));
        card.setMinimumSize(new Dimension(350, 420));
        
        JLabel title = UIStyles.heading("Welcome Back");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subTitle = UIStyles.label("Please login to your account");
        subTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel userPanel = new JPanel(new BorderLayout(0, 5));
        userPanel.setOpaque(false);
        userPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        userPanel.add(UIStyles.label("Username"), BorderLayout.NORTH);
        JTextField user = UIStyles.input();
        user.setText("admin");
        userPanel.add(user, BorderLayout.CENTER);

        JPanel passPanel = new JPanel(new BorderLayout(0, 5));
        passPanel.setOpaque(false);
        passPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        passPanel.add(UIStyles.label("Password"), BorderLayout.NORTH);
        JPasswordField pass = UIStyles.passwordInput();
        pass.setText("1234");
        passPanel.add(pass, BorderLayout.CENTER);

        JButton login = UIStyles.button("Login");
        login.setAlignmentX(Component.CENTER_ALIGNMENT);
        login.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45)); // make button stretch

        login.addActionListener(e -> {
            if(user.getText().equals("admin") && String.valueOf(pass.getPassword()).equals("1234")){
                new Dashboard();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,"Invalid Credentials", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        card.add(title);
        card.add(Box.createRigidArea(new Dimension(0, 5)));
        card.add(subTitle);
        card.add(Box.createRigidArea(new Dimension(0, 30)));
        card.add(userPanel);
        card.add(Box.createRigidArea(new Dimension(0, 15)));
        card.add(passPanel);
        card.add(Box.createRigidArea(new Dimension(0, 25)));
        card.add(login);

        rightPanel.add(card);

        root.add(leftPanel, BorderLayout.WEST);
        root.add(rightPanel, BorderLayout.CENTER);
        
        add(root);
        setVisible(true);
    }

    public static void main(String[] args) {
        initDB();
        SwingUtilities.invokeLater(() -> new LoginScreen());
    }
    
    private static void initDB() {
        try {
            Class.forName("org.sqlite.JDBC");
            try (Connection con = DriverManager.getConnection("jdbc:sqlite:restaurant_db.db");
                 Statement stmt = con.createStatement()) {
                stmt.execute("CREATE TABLE IF NOT EXISTS food_items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, price REAL)");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}